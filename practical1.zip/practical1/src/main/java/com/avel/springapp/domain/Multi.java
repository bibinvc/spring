package com.avel.springapp.domain;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Multi {

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());


    private int ssn;
    private int mn;
    
    public int getSsn() {
        return ssn;
    }

    public void setSsn(int ssn) {
        this.ssn = ssn;
    }

    public int getMn() {
        return mn;
    }

    public void setMn(int mn) {
        this.mn = mn;
    }


}