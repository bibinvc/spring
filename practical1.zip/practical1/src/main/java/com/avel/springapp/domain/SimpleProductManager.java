package com.avel.springapp.domain;

import java.util.List;



import com.avel.springapp.domain.Product;
import org.springframework.stereotype.Component;

@Component
public class SimpleProductManager implements ProductManager {

	private static final long serialVersionUID = 1L;
	private List<Product> products;

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}


	public void cal(int ssn, int mn) {
		List<Product> products = getProducts();
		if (products != null) {
			for (Product product : products) {
				double mulv = mn*100.0;
				product.setDescription("Social Security Number : "+ssn+"\n Bonus: "+mulv);
				//product.Ssnvd("   The SSN value is"+ssn);

			}
		}
				
	}

}