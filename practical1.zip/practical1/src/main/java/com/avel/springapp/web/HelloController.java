package com.avel.springapp.web;

import java.util.Date;
import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.avel.springapp.domain.ProductManager;

@Controller
public class HelloController {

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private ProductManager productManager;

	@RequestMapping(value = "/hello.htm")
	public String handleRequest(Locale locale, Model model) {

		logger.info("Returning hello view");
		String now = (new Date()).toString();
		logger.info("Returning hello avec " + now);
		//model.addAttribute("now", now);
		model.addAttribute("products", this.productManager.getProducts());
		return ("/hello");
	}

	public void setProductManager(ProductManager productManager) {
		this.productManager = productManager;
	}

}