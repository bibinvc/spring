package com.avel.springapp.domain;

import java.io.Serializable;
import java.util.List;

import com.avel.springapp.domain.Product;



public interface ProductManager extends Serializable {


    public void cal(int ssn,int mn);

    public List<Product> getProducts();
    

}