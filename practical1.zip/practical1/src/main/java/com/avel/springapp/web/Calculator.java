package com.avel.springapp.web;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.avel.springapp.domain.Multi;
import com.avel.springapp.domain.ProductManager;

@Controller
@RequestMapping(value="/calculator.htm")
public class Calculator {

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());

    @Autowired
    private ProductManager productManager;

    @RequestMapping(method = RequestMethod.POST)
    public String onSubmit(@Valid  @ModelAttribute("multi") Multi multi, BindingResult result)
    {
        if (result.hasErrors()) {
            return "/calculator";
        }
		
        int snnf = multi.getSsn();
        int mnf = multi.getMn();

        logger.info("Increasing prices by " + snnf + ".");
        logger.info("Increasing prices by " + mnf + ".");


        productManager.cal(snnf,mnf);

        return "redirect:/hello.htm";
    }

    @RequestMapping(method = RequestMethod.GET)
    protected String  formBackingObject(Model model)  {
    	Multi multi = new Multi();
    	multi.setSsn(10);
    	multi.setMn(20);
        model.addAttribute("multi", multi);
        return "/calculator";
    }

    public void setProductManager(ProductManager productManager) {
        this.productManager = productManager;
    }

    public ProductManager getProductManager() {
        return productManager;
    }

}