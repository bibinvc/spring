package com.avel.springapp.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the multiplier database table.
 * 
 */
@Entity
@Table(name="multiplier")
@NamedQuery(name="Multiplier.findAll", query="SELECT p FROM Multiplier p")
public class Product implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int ssn;

	private int multiplier;

	private Double bonus;

	public Product() {
	}

    public int getSsn() {
        return ssn;
    }

    public void setSsn(int ssn) {
        this.ssn = ssn;
    }

    public int getMultiplier() {
        return multiplier;
    }

    public void setMultiplier(int multiplier) {
        this.multiplier = multiplier;
    }

    public Double getBonus() {
        return bonus;
    }

    public void setBonus(Double bonus) {
        this.bonus = bonus;
    }

    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setDescription(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

	

}