package com.avel.springapp.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.avel.springapp.domain.Product;
import com.avel.springapp.repository.ProductDao;
import java.util.ArrayList;

@Component
public class SimpleProductManager implements ProductManager {

    private static final long serialVersionUID = 1L;

    @Autowired
    private ProductDao productDao;

    public void setProductDao(ProductDao productDao) {
        this.productDao = productDao;
    }

    public List<Product> getProducts() {
        return productDao.getProductList();
    }

    public void cal(int ssn1, int mn1,int ssn2, int mn2,int ssn3, int mn3) {
		List<Product> products = getProducts();
		ArrayList<Double> list = new ArrayList<Double>();
		ArrayList<Double> ssnl = new ArrayList<Double>();
		ssnl.add((double) ssn1);
		ssnl.add((double) ssn2);
		ssnl.add((double) ssn3);
		double mulv1 = ssn1*mn1;
		double mulv2 = ssn2*mn2;
		double mulv3 = ssn3*mn3;
		list.add(mulv1);
		list.add(mulv2);
		list.add(mulv3);

		if (products != null) {
			for (Product product : products) {
				int i = 0;
				
				product.setDescription("The calculated value for ssn"+ssnl.get(product.getId())+" is :"+list.get(product.getId()));
				//product.Ssnvd("   The SSN value is"+ssn);
               
			}
		}
				
	}
}