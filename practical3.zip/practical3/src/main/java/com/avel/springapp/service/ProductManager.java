package com.avel.springapp.service;

import java.io.Serializable;
import java.util.List;

import com.avel.springapp.domain.Product;



public interface ProductManager extends Serializable {

    public void cal(int ssn1,int m1,int ssn2,int m2,int ssn3,int m3);
    
    public List<Product> getProducts();

}