package com.avel.springapp.web;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.avel.springapp.service.PriceIncrease;
import com.avel.springapp.service.ProductManager;

@Controller
@RequestMapping(value="/priceincrease.htm")
public class PriceIncreaseFormController {

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());

    @Autowired
    private ProductManager productManager;

    @RequestMapping(method = RequestMethod.POST)
    public String onSubmit(@Valid  @ModelAttribute("priceIncrease") PriceIncrease priceIncrease, BindingResult result)
    {
        if (result.hasErrors()) {
            return "/priceincrease";
        }
		
        int snnf1 = priceIncrease.getSsn1();
        int mnf1 = priceIncrease.getMn1();
        int snnf2 = priceIncrease.getSsn2();
        int mnf2 = priceIncrease.getMn2();
        int snnf3 = priceIncrease.getSsn3();
        int mnf3 = priceIncrease.getMn3();

        logger.info("Increasing prices by " + snnf1 + ".");
        logger.info("Increasing prices by " + mnf1 + ".");
        logger.info("Increasing prices by " + snnf2 + ".");
        logger.info("Increasing prices by " + mnf2 + ".");
        logger.info("Increasing prices by " + snnf3 + ".");
        logger.info("Increasing prices by " + mnf3 + ".");

        productManager.cal(snnf1,mnf1,snnf2,mnf2,snnf3,mnf3);

        return "redirect:/hello.htm";
    }

    @RequestMapping(method = RequestMethod.GET)
    protected String  formBackingObject(Model model)  {
        PriceIncrease priceIncrease = new PriceIncrease();
        //priceIncrease.setPercentage(15);
        
    	priceIncrease.setSsn1(1);
    	priceIncrease.setMn1(2);
    	priceIncrease.setSsn2(3);
    	priceIncrease.setMn2(4);
    	priceIncrease.setSsn3(5);
    	priceIncrease.setMn3(6);
        model.addAttribute("priceIncrease", priceIncrease);
        
        return "/priceincrease";
    }

   
    

    public ProductManager getProductManager() {
        return productManager;
    }

}