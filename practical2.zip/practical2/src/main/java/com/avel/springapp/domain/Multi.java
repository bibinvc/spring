package com.avel.springapp.domain;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Multi {

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());


    private int ssn1;
    private int mn1;
    private int ssn2;
    private int mn2;
    private int ssn3;
    private int mn3;
    
    public int getSsn1() {
        return ssn1;
    }

    public void setSsn1(int ssn1) {
        this.ssn1 = ssn1;
    }

    public int getMn1() {
        return mn1;
    }

    public void setMn1(int mn1) {
        this.mn1 = mn1;
    }

    public int getSsn2() {
        return ssn2;
    }

    public void setSsn2(int ssn2) {
        this.ssn2 = ssn2;
    }

    public int getMn2() {
        return mn2;
    }

    public void setMn2(int mn2) {
        this.mn2 = mn2;
    }

    public int getSsn3() {
        return ssn3;
    }

    public void setSsn3(int ssn3) {
        this.ssn3 = ssn3;
    }

    public int getMn3() {
        return mn3;
    }

    public void setMn3(int mn3) {
        this.mn3 = mn3;
    }


}